import 'package:flutter/material.dart';
import 'package:myroom/NovaTela.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  bool _cadastrar = false;

  void _enviarFormulario() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => NovaTela()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFFFF111), // Cor de cima (#1D4578)
              Color(0xFF1D4578), // Cor de baixo (#FFF111)
            ],
          ),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Text(
                    'MYROOM',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Color(0xff000000),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(bottom: 16),
                    child: Image.asset(
                      'assets/imagem/logoMY.png',
                      width: 150,
                      height: 150,
                    ),
                  ),
                  Container(
                    width: double.infinity,
                    height: 340,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(25),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.3),
                          blurRadius: 10,
                          offset: Offset(0, 3),
                        ),
                      ],
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: EdgeInsets.only(bottom: 16),
                          child: Container(
                            width: 306,
                            height: 71,
                            child: TextField(
                              autofocus: true,
                              keyboardType: TextInputType.emailAddress,
                              style:
                                  TextStyle(fontSize: 20, color: Colors.black),
                              decoration: InputDecoration(
                                contentPadding:
                                    EdgeInsets.fromLTRB(32, 16, 32, 16),
                                hintText: "Usuário",
                                filled: true,
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                fillColor: Colors.white,
                                hintStyle: TextStyle(
                                  color: Colors.black.withOpacity(0.7),
                                ),
                                prefixIcon: Icon(Icons.person,
                                    color: Color.fromARGB(255, 0, 0, 0)),
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(bottom: 16),
                          child: Container(
                            width: 306,
                            height: 71,
                            child: TextField(
                              obscureText: true,
                              keyboardType: TextInputType.text,
                              style:
                                  TextStyle(fontSize: 20, color: Colors.black),
                              decoration: InputDecoration(
                                contentPadding:
                                    EdgeInsets.fromLTRB(32, 16, 32, 16),
                                hintText: "Senha",
                                filled: true,
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                fillColor: Colors.white,
                                hintStyle: TextStyle(
                                  color: Colors.black.withOpacity(0.7),
                                ),
                                prefixIcon:
                                    Icon(Icons.lock, color: Colors.black),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 16),
                        Container(
                          width: 200,
                          height: 60,
                          child: ElevatedButton(
                            onPressed: _enviarFormulario,
                            style: ButtonStyle(
                              backgroundColor: MaterialStateProperty.all<Color>(
                                Color.fromARGB(255, 229, 241, 0),
                              ),
                              minimumSize: MaterialStateProperty.all<Size>(
                                Size(double.infinity, 60),
                              ),
                            ),
                            child: Text(
                              'Entrar',
                              style: TextStyle(
                                fontSize: 30,
                                color: Color.fromARGB(255, 0, 0, 0),
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 16),
                  InkWell(
                    onTap: () {
                      print('Botão esqueceu a senha pressionado!');
                    },
                    child: Text(
                      'Ainda não tem conta? Criar',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        decoration: TextDecoration.underline,
                        color: Colors.white,
                        fontSize: 16,
                      ),
                    ),
                  ),
                  SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

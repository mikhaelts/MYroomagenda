import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';

class AgendarHorarioTela extends StatefulWidget {
  @override
  _AgendarHorarioTelaState createState() => _AgendarHorarioTelaState();
}

class _AgendarHorarioTelaState extends State<AgendarHorarioTela> {
  CalendarFormat _calendarFormat = CalendarFormat.month;
  DateTime _selectedDay = DateTime.now();
  DateTime _focusedDay = DateTime.now();
  TimeOfDay? _selectedTime;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Agendar Horário'),
        backgroundColor: Color(0xFF1D4578),
      ),
      body: Column(
        children: [
          TableCalendar(
            calendarFormat: _calendarFormat,
            focusedDay: _focusedDay,
            firstDay: DateTime.utc(2023, 1, 1),
            lastDay: DateTime.utc(2023, 12, 31),
            selectedDayPredicate: (day) {
              return isSameDay(_selectedDay, day);
            },
            onDaySelected: (selectedDay, focusedDay) {
              setState(() {
                _selectedDay = selectedDay;
                _focusedDay = focusedDay;
              });
            },
            onFormatChanged: (format) {
              setState(() {
                _calendarFormat = format;
              });
            },
            onPageChanged: (focusedDay) {
              _focusedDay = focusedDay;
            },
          ),
          SizedBox(height: 16),
          ElevatedButton(
            onPressed: () {
              _selectTime(context);
            },
            child: Text('Selecionar Horário'),
          ),
          SizedBox(height: 16),
          Text(
            'Data selecionada: ${_selectedDay.toString()}',
            style: TextStyle(fontSize: 16),
          ),
          SizedBox(height: 8),
          Text(
            'Horário selecionado: ${_selectedTime?.format(context) ?? "Nenhum horário selecionado"}',
            style: TextStyle(fontSize: 16),
          ),
        ],
      ),
    );
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? selectedTime = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );

    if (selectedTime != null) {
      setState(() {
        _selectedTime = selectedTime;
      });
    }
  }
}

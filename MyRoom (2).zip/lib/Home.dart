import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:myroom/NovaTela.dart';
import 'dart:convert';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  bool _cadastrar = false;
  TextEditingController _matriculaController = TextEditingController();
  TextEditingController _senhaController = TextEditingController();

  @override
  void dispose() {
    _matriculaController.dispose();
    _senhaController.dispose();
    super.dispose();
  }

  Future<bool> verificarCredenciaisNaAPI(String matricula, String senha) async {
    var url = Uri.parse('http://192.168.0.106:8080/cadastros/cadastro');
    var headers = {'Content-Type': 'application/json'};
    var body = jsonEncode({
      'matricula': matricula,
      'senha': senha,
    });

    var response = await http.post(url, headers: headers, body: body);

    if (response.statusCode == 201) {
      return true;
    } else if (response.statusCode == 400) {
      return false;
    } else {
      throw Exception('Erro na API. Status code: ${response.statusCode}');
    }
  }

  void _enviarFormulario(BuildContext context) async {
    String matricula = _matriculaController.text;
    String senha = _senhaController.text;

    bool credenciaisValidas = await verificarCredenciaisNaAPI(matricula, senha);

    if (credenciaisValidas) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => NovaTela()),
      );
    } else {
      showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Text('Credenciais inválidas'),
            content: Text('A matrícula ou senha inseridas são inválidas.'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: Text('OK'),
              ),
            ],
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xff395862), // Cor de cima (#1D4578)
              Color(0xff012b39), // Cor de baixo (#FFF111)
            ],
          ),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Text(
                    'MYROOM',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Color(0xfff8f8f8),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(bottom: 16),
                    child: Image.asset(
                      'assets/imagem/logo.png',
                      width: 150,
                      height: 150,
                    ),
                  ),
                  Container(
                    width: double.infinity,
                    height: 340,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(25),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.3),
                          blurRadius: 10,
                          offset: Offset(0, 3),
                        ),
                      ],
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: EdgeInsets.only(bottom: 16),
                          child: Container(
                            width: 306,
                            height: 71,
                            child: TextField(
                              controller: _matriculaController,
                              autofocus: true,
                              keyboardType: TextInputType.emailAddress,
                              style:
                                  TextStyle(fontSize: 20, color: Colors.black),
                              decoration: InputDecoration(
                                contentPadding:
                                    EdgeInsets.fromLTRB(32, 16, 32, 16),
                                hintText: "Matricula",
                                filled: true,
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                fillColor: Colors.white,
                                hintStyle: TextStyle(
                                  color: Colors.black.withOpacity(0.7),
                                ),
                                prefixIcon: Icon(Icons.person,
                                    color: Color.fromARGB(255, 0, 0, 0)),
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(bottom: 16),
                          child: Container(
                            width: 306,
                            height: 71,
                            child: TextField(
                              controller: _senhaController,
                              obscureText: true,
                              keyboardType: TextInputType.text,
                              style:
                                  TextStyle(fontSize: 20, color: Colors.black),
                              decoration: InputDecoration(
                                contentPadding:
                                    EdgeInsets.fromLTRB(32, 16, 32, 16),
                                hintText: "Senha",
                                filled: true,
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                fillColor: Colors.white,
                                hintStyle: TextStyle(
                                  color: Colors.black.withOpacity(0.7),
                                ),
                                prefixIcon:
                                    Icon(Icons.lock, color: Colors.black),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 16),
                        Container(
                          width: 200,
                          height: 60,
                          child: ElevatedButton(
                            onPressed: () => _enviarFormulario(context),
                            style: ButtonStyle(
                              backgroundColor: MaterialStateProperty.all<Color>(
                                Color(0xff395862),
                              ),
                              minimumSize: MaterialStateProperty.all<Size>(
                                Size(double.infinity, 60),
                              ),
                            ),
                            child: Text(
                              'Entrar',
                              style: TextStyle(
                                fontSize: 30,
                                color: Color(0xffffffff),
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 16),
                  InkWell(
                    onTap: () {
                      print('Botão esqueceu a senha pressionado!');
                    },
                    child: Text(
                      'Ainda não tem conta? Criar',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        decoration: TextDecoration.underline,
                        color: Colors.white,
                        fontSize: 16,
                      ),
                    ),
                  ),
                  SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

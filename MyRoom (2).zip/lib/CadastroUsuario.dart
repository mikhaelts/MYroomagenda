import 'package:flutter/material.dart';
import 'NovaTela.dart';

class CadastroUsuario extends StatefulWidget {
  @override
  _CadastroUsuarioState createState() => _CadastroUsuarioState();
}

class _CadastroUsuarioState extends State<CadastroUsuario> {
  TextEditingController nomeController = TextEditingController();
  TextEditingController matriculaController = TextEditingController();
  TextEditingController senhaController = TextEditingController();

  void _enviarFormulario() {
    String nome = nomeController.text;
    String matricula = matriculaController.text;
    String senha = senhaController.text;

    print('Nome: $nome');
    print('Matrícula: $matricula');
    print('Senha: $senha');

    // Perform any desired actions with the form values
    // For example, you can send the data to a server or perform validation
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Cadastro de Usuário'),
        backgroundColor: Color(0xff000000),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(
              context,
              MaterialPageRoute(builder: (context) => NovaTela()),
            );
          },
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xff395862), // Cor de cima (#1D4578)
              Color(0xff012b39), // Cor de baixo (#FFF111)
            ],
          ),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Text(
                    '',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Color(0xff000000),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(bottom: 16),
                    child: Image.asset(
                      'assets/imagem/logo.png',
                      width: 150,
                      height: 150,
                    ),
                  ),
                  Container(
                    width: double.infinity,
                    height: 400,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(25),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.3),
                          blurRadius: 10,
                          offset: Offset(0, 3),
                        ),
                      ],
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: EdgeInsets.only(bottom: 16),
                          child: Container(
                            width: 306,
                            height: 71,
                            child: TextField(
                              autofocus: true,
                              keyboardType: TextInputType.text,
                              style:
                                  TextStyle(fontSize: 20, color: Colors.black),
                              decoration: InputDecoration(
                                contentPadding:
                                    EdgeInsets.fromLTRB(32, 16, 32, 16),
                                hintText: "Nome",
                                filled: true,
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                fillColor: Colors.white,
                                hintStyle: TextStyle(
                                  color: Colors.black.withOpacity(0.7),
                                ),
                                prefixIcon: Icon(Icons.person,
                                    color: Color.fromARGB(255, 0, 0, 0)),
                              ),
                              controller: nomeController,
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(bottom: 16),
                          child: Container(
                            width: 306,
                            height: 71,
                            child: TextField(
                              keyboardType: TextInputType.number,
                              style:
                                  TextStyle(fontSize: 20, color: Colors.black),
                              decoration: InputDecoration(
                                contentPadding:
                                    EdgeInsets.fromLTRB(32, 16, 32, 16),
                                hintText: "Matrícula",
                                filled: true,
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                fillColor: Colors.white,
                                hintStyle: TextStyle(
                                  color: Colors.black.withOpacity(0.7),
                                ),
                                prefixIcon: Icon(Icons.badge,
                                    color: Color.fromARGB(255, 0, 0, 0)),
                              ),
                              controller: matriculaController,
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(bottom: 16),
                          child: Container(
                            width: 306,
                            height: 71,
                            child: TextField(
                              obscureText: true,
                              keyboardType: TextInputType.text,
                              style:
                                  TextStyle(fontSize: 20, color: Colors.black),
                              decoration: InputDecoration(
                                contentPadding:
                                    EdgeInsets.fromLTRB(32, 16, 32, 16),
                                hintText: "Senha",
                                filled: true,
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(14),
                                ),
                                fillColor: Colors.white,
                                hintStyle: TextStyle(
                                  color: Colors.black.withOpacity(0.7),
                                ),
                                prefixIcon:
                                    Icon(Icons.lock, color: Colors.black),
                              ),
                              controller: senhaController,
                            ),
                          ),
                        ),
                        SizedBox(height: 16),
                        Container(
                          width: 200,
                          height: 60,
                          child: ElevatedButton(
                            onPressed: _enviarFormulario,
                            style: ButtonStyle(
                              backgroundColor: MaterialStateProperty.all<Color>(
                                Color(0xff012b39),
                              ),
                              minimumSize: MaterialStateProperty.all<Size>(
                                Size(double.infinity, 60),
                              ),
                            ),
                            child: Text(
                              'Cadastrar',
                              style: TextStyle(
                                fontSize: 30,
                                color: Color(0xffffffff),
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 16),
                  InkWell(
                    onTap: () {
                      print('');
                    },
                    child: Text(
                      '',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        decoration: TextDecoration.underline,
                        color: Colors.white,
                        fontSize: 16,
                      ),
                    ),
                  ),
                  SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class NovaTela extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Nova Tela'),
      ),
      body: Center(
        child: Text('Esta é a nova tela!'),
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    initialRoute: '/',
    routes: {
      '/': (context) => CadastroUsuario(),
      'NovaTela': (context) => NovaTela(),
    },
  ));
}

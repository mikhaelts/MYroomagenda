import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class AgendarHorarioTela extends StatefulWidget {
  @override
  _AgendarHorarioTelaState createState() => _AgendarHorarioTelaState();
}

class _AgendarHorarioTelaState extends State<AgendarHorarioTela> {
  CalendarFormat _calendarFormat = CalendarFormat.month;
  DateTime _selectedDay = DateTime.now();
  DateTime _focusedDay = DateTime.now();
  TimeOfDay? _selectedTime;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Agendar Horário'),
        backgroundColor: Color(0xff012b39),
      ),
      body: Column(
        children: [
          TableCalendar(
            calendarFormat: _calendarFormat,
            focusedDay: _focusedDay,
            firstDay: DateTime.utc(2023, 1, 1),
            lastDay: DateTime.utc(2023, 12, 31),
            selectedDayPredicate: (day) {
              return isSameDay(_selectedDay, day);
            },
            onDaySelected: (selectedDay, focusedDay) {
              setState(() {
                _selectedDay = selectedDay;
                _focusedDay = focusedDay;
              });
            },
            onFormatChanged: (format) {
              setState(() {
                _calendarFormat = format;
              });
            },
            onPageChanged: (focusedDay) {
              setState(() {
                _focusedDay = focusedDay;
              });
            },
          ),
          SizedBox(height: 16),
          ElevatedButton(
            onPressed: () {
              _selectTime(context);
            },
            child: Text('Selecionar Horário'),
          ),
          SizedBox(height: 16),
          Text(
            'Data selecionada: ${_selectedDay.toString()}',
            style: TextStyle(fontSize: 16),
          ),
          SizedBox(height: 8),
          Text(
            'Horário selecionado: ${_selectedTime?.format(context) ?? "Nenhum horário selecionado"}',
            style: TextStyle(fontSize: 16),
          ),
          SizedBox(height: 16),
          ElevatedButton(
            onPressed: _showConfirmationDialog,
            child: Text('Agendar'),
          ),
        ],
      ),
    );
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? selectedTime = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );

    if (selectedTime != null) {
      setState(() {
        _selectedTime = selectedTime;
      });
    }
  }

  Future<void> _showConfirmationDialog() async {
    if (_selectedTime == null) {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Erro'),
            content: Text('Selecione um horário antes de agendar.'),
            actions: [
              TextButton(
                child: Text('Fechar'),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          );
        },
      );
      return;
    }

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Confirmar Agendamento'),
          content: Text('Deseja agendar o horário selecionado?'),
          actions: [
            TextButton(
              child: Text('Cancelar'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: Text('Agendar'),
              onPressed: () async {
                Navigator.of(context).pop();

                await saveData(); // Chamando a função saveData()
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> _showSuccessDialog() async {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Agendamento Confirmado'),
          content: Text('Seu horário foi agendado com sucesso!'),
          actions: [
            TextButton(
              child: Text('Fechar'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> saveData() async {
    final selectedDateTime = DateTime(
      _selectedDay.year,
      _selectedDay.month,
      _selectedDay.day,
      _selectedTime!.hour,
      _selectedTime!.minute,
    );

    final url = Uri.parse('http:localhost:8080/agendamentos/agendamento');

    final requestData = {
      'data': selectedDateTime.toIso8601String(),
      'horario': '${_selectedTime!.hour}:${_selectedTime!.minute}',
      // Adicione outras informações relevantes do agendamento aqui
    };

    try {
      final http.Response response = await http.post(
        url,
        body: jsonEncode(requestData),
        headers: {
          'Content-Type': 'application/json',
        },
      );

      if (response.statusCode == 201) {
        _showSuccessDialog();
        // O POST foi bem-sucedido, você pode processar a resposta aqui
        print(response.body);
      } else {
        // O POST falhou
        print('Falha no POST: ${response.statusCode}');
      }
    } catch (error) {
      // Ocorreu um erro durante o POST
      print('Erro no POST: $error');
    }
  }
}

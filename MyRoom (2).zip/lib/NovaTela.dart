import 'package:flutter/material.dart';
import 'package:myroom/CadastroUsuario.dart';
import 'agendar_horario_tela.dart';
import 'CadastroUsuario.dart';
// Importe o arquivo com a tela de Agendar Horário

class NovaTela extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'MyRoom',
          style: TextStyle(
            color: Color(0xffffffff),
          ),
        ),
        backgroundColor: Color(0xff012b39),
        iconTheme: IconThemeData(
          color: Color(0xffffffff), // Altere a cor da seta de voltar para preto
        ),
      ),
      body: GridView.count(
        crossAxisCount: 2,
        padding: EdgeInsets.all(16),
        children: [
          _buildCard(
            Icon(Icons.person_add),
            'Cadastrar Usuários',
            () {
              // Navegar para a tela de agendamento
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => CadastroUsuario()),
              );
            },
          ),
          _buildCard(
            Icon(Icons.calendar_today),
            'Agendar Horário',
            () {
              // Navegar para a tela de agendamento
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AgendarHorarioTela()),
              );
            },
          ),
          _buildCard(
            Icon(Icons.schedule),
            'Listar Agendamentos',
            () {
              // Navegar para a tela de agendamento
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AgendarHorarioTela()),
              );
            },
          ),
          _buildCard(
            Icon(Icons.people),
            'Listar Usuários',
            () {
              // Navegar para a tela de agendamento
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AgendarHorarioTela()),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildCard(Icon icon, String title, VoidCallback onTap) {
    return Card(
      child: InkWell(
        onTap: onTap,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            icon,
            SizedBox(height: 8),
            Text(
              title,
              style: TextStyle(fontSize: 16),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
